import urduhack
urduhack.download()

import nltk
nltk.download('punkt')
